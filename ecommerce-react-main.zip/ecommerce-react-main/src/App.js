import React from 'react'
import Nav from './component/Nav'
import Cart from './component/Cart'
import './App.css'


function App() {
  return (
    <div>
        <Nav />
        <Cart />
    </div>
  )
}

export default App
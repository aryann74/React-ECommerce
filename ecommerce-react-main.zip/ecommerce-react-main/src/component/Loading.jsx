import React from 'react'

function Loading() {
  return (
    <div style={{fontFamily:'cursive',fontSize:'28px'}}>
        Lodding ....
    </div>
  )
}

export default Loading